package com.clark.exceptions;

public class FooRunTimeException extends Exception{
	public FooRunTimeException(String message) {
		super(message);
	}
}
