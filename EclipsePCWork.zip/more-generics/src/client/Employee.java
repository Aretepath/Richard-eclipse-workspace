package client;

public class Employee {
	
	public void work() {
		System.out.println("Employeee working...");
	}


}
