package client;

public class Accountant extends Employee {
	
	@Override
	public void work() {
		System.out.println("Accountant working...");
	}

}
