package car_dealership;

public class dealership {

	public static void main(String[] args) {
		Customer cust1 = new Customer();
		cust1.setName("Tom");
		cust1.setAddress("123 anything street"); 
		cust1.setCashOnHand(8000);
		
		Vehicle vehicle = new Vehicle();
		vehicle.setModel("Honda");
		vehicle.setMake("Accord");
		vehicle.setPrice(10000);
		
		Employee emp = new Employee();
		
		cust1.purchaseCar(vehicle, emp, false);
		
		

	}

}