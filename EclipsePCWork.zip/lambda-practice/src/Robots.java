
public class Robots implements walkable {
	public void walk() {
		System.out.println("Robot Walking");
	}

}
