
@FunctionalInterface
public interface walkable {
	public void walk();

}

//functional interface for lambda expression can only have one method without a body
