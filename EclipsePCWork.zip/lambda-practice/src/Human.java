
public class Human implements walkable{
	public void walk() {
		System.out.println("Human Walking");
	}

}
