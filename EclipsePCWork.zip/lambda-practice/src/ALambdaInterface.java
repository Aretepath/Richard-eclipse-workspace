
public interface ALambdaInterface {
	public void sometype();
	
}
