
public interface Calculate {
	public int compute(int a, int b);

}
